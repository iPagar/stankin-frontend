self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6513a60ed695608a9e896c4057cbaaf5",
    "url": "/index.html"
  },
  {
    "revision": "acd9908c082bcf0a5529",
    "url": "/static/css/2.8cdfe4cf.chunk.css"
  },
  {
    "revision": "2b40eff1507421c150fc",
    "url": "/static/css/main.975c90e3.chunk.css"
  },
  {
    "revision": "acd9908c082bcf0a5529",
    "url": "/static/js/2.b65a4530.chunk.js"
  },
  {
    "revision": "fd1f6eb2b1de54cf427a0033837e57fa",
    "url": "/static/js/2.b65a4530.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9c4c9d1f90df7b6c0865",
    "url": "/static/js/3.76c33157.chunk.js"
  },
  {
    "revision": "7ec01595672f75e83fd81b41f132f4c1",
    "url": "/static/js/3.76c33157.chunk.js.LICENSE.txt"
  },
  {
    "revision": "987649817f6d44e6f311",
    "url": "/static/js/4.b07ac541.chunk.js"
  },
  {
    "revision": "0512cf1466087f5c44c5c61e4b32a001",
    "url": "/static/js/4.b07ac541.chunk.js.LICENSE.txt"
  },
  {
    "revision": "84907cb0c3c35ce84361",
    "url": "/static/js/5.93f10d9e.chunk.js"
  },
  {
    "revision": "3a7bc1760b9d274e2e5e7531bce86076",
    "url": "/static/js/5.93f10d9e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2b40eff1507421c150fc",
    "url": "/static/js/main.a3217367.chunk.js"
  },
  {
    "revision": "ec2bb25ab500cc108b56",
    "url": "/static/js/runtime-main.318f239c.js"
  },
  {
    "revision": "dedc6017ad900f38507f7f58d881522a",
    "url": "/static/media/angry.dedc6017.svg"
  },
  {
    "revision": "9abf9fb060c791356d0175d6c898deba",
    "url": "/static/media/dislike.9abf9fb0.svg"
  },
  {
    "revision": "05fc24548e6eeec20b896ef498f7de66",
    "url": "/static/media/haha.05fc2454.svg"
  },
  {
    "revision": "c2d64a6df79c270f2fe6d336e4905155",
    "url": "/static/media/like.c2d64a6d.svg"
  },
  {
    "revision": "ecb2c77920833f4e69615c39db1766d1",
    "url": "/static/media/logoblack.ecb2c779.png"
  },
  {
    "revision": "b7e5f0dfd2855ba5a97bc91672861875",
    "url": "/static/media/love.b7e5f0df.svg"
  },
  {
    "revision": "f01a5d278532839a76d7e5333aff13d1",
    "url": "/static/media/think.f01a5d27.png"
  },
  {
    "revision": "bc15456231f9e62d4c75306ba3834cdc",
    "url": "/static/media/yaw.bc154562.png"
  }
]);