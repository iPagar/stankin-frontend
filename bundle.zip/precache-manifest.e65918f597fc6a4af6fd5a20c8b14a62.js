self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "aa7911b0d1fa8237f79ba74e3bf0505a",
    "url": "/index.html"
  },
  {
    "revision": "980cb2aead856adb4172",
    "url": "/static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "8f85a236265c56ce785a",
    "url": "/static/css/main.975c90e3.chunk.css"
  },
  {
    "revision": "980cb2aead856adb4172",
    "url": "/static/js/2.385c01eb.chunk.js"
  },
  {
    "revision": "9f316576cf8db6583818f6dc1f070f3c",
    "url": "/static/js/2.385c01eb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8f85a236265c56ce785a",
    "url": "/static/js/main.e8e8ad7b.chunk.js"
  },
  {
    "revision": "7969d66359612046dbf3",
    "url": "/static/js/runtime-main.89369434.js"
  },
  {
    "revision": "ecb2c77920833f4e69615c39db1766d1",
    "url": "/static/media/logoblack.ecb2c779.png"
  }
]);