self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e5e1c42b8dbeacdbec1b89461f1dae0b",
    "url": "/index.html"
  },
  {
    "revision": "9f333f57e3536189654b",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "9f333f57e3536189654b",
    "url": "/static/js/2.54a9f0af.chunk.js"
  },
  {
    "revision": "40f6ddb379fd6d5397eded99d3b7f8f9",
    "url": "/static/js/2.54a9f0af.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9e6a3a83a238c47e49b6",
    "url": "/static/js/main.7b084fc7.chunk.js"
  },
  {
    "revision": "72419f9ea32f042f05da",
    "url": "/static/js/runtime-main.33842ec9.js"
  },
  {
    "revision": "ecb2c77920833f4e69615c39db1766d1",
    "url": "/static/media/logoblack.ecb2c779.png"
  }
]);