self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "eb627d9768fd34648e7ecffa824d571b",
    "url": "/index.html"
  },
  {
    "revision": "874398b55e1b6919ec9e",
    "url": "/static/css/2.8cdfe4cf.chunk.css"
  },
  {
    "revision": "3251be584ff5f65c642c",
    "url": "/static/css/main.975c90e3.chunk.css"
  },
  {
    "revision": "874398b55e1b6919ec9e",
    "url": "/static/js/2.dc120ed9.chunk.js"
  },
  {
    "revision": "fd1f6eb2b1de54cf427a0033837e57fa",
    "url": "/static/js/2.dc120ed9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "bc9445a55b3b60697d69",
    "url": "/static/js/3.60b6d0de.chunk.js"
  },
  {
    "revision": "7ec01595672f75e83fd81b41f132f4c1",
    "url": "/static/js/3.60b6d0de.chunk.js.LICENSE.txt"
  },
  {
    "revision": "96e11e4175a00e3cebaa",
    "url": "/static/js/4.376c7964.chunk.js"
  },
  {
    "revision": "0512cf1466087f5c44c5c61e4b32a001",
    "url": "/static/js/4.376c7964.chunk.js.LICENSE.txt"
  },
  {
    "revision": "86ed321305254ea705b8",
    "url": "/static/js/5.22d92ce7.chunk.js"
  },
  {
    "revision": "3a7bc1760b9d274e2e5e7531bce86076",
    "url": "/static/js/5.22d92ce7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3251be584ff5f65c642c",
    "url": "/static/js/main.40a21b9b.chunk.js"
  },
  {
    "revision": "5c69304781bd8c8c021d",
    "url": "/static/js/runtime-main.3fc8505e.js"
  },
  {
    "revision": "dedc6017ad900f38507f7f58d881522a",
    "url": "/static/media/angry.dedc6017.svg"
  },
  {
    "revision": "9abf9fb060c791356d0175d6c898deba",
    "url": "/static/media/dislike.9abf9fb0.svg"
  },
  {
    "revision": "05fc24548e6eeec20b896ef498f7de66",
    "url": "/static/media/haha.05fc2454.svg"
  },
  {
    "revision": "c2d64a6df79c270f2fe6d336e4905155",
    "url": "/static/media/like.c2d64a6d.svg"
  },
  {
    "revision": "ecb2c77920833f4e69615c39db1766d1",
    "url": "/static/media/logoblack.ecb2c779.png"
  },
  {
    "revision": "b7e5f0dfd2855ba5a97bc91672861875",
    "url": "/static/media/love.b7e5f0df.svg"
  },
  {
    "revision": "f01a5d278532839a76d7e5333aff13d1",
    "url": "/static/media/think.f01a5d27.png"
  },
  {
    "revision": "bc15456231f9e62d4c75306ba3834cdc",
    "url": "/static/media/yaw.bc154562.png"
  }
]);